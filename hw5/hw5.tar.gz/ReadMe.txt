-------------------------------

HOW TO COMPILE:
--------------------------------
Makefile is included, simply enters:
make
an executable named hw5 is created.
********************************
GUIDELINE
********************************
THE COMMANDLINE SYNTAX:
--------------------------------
hw5 tablecheck -t=tablefile
hw5 encrypt -k=key -t=tablefile [file]
hw5 decrypt -k=key -t=tablefile [file]
hw5 encrypt3 -k=key3 -t=tablefile [file]
hw5 decrypt3 -k=key3 -t=tablefile [file]