// DES.cpp : Defines the entry point for the console application.
//
#include "hw5.h"
#include "stdlib.h"
#include "stdio.h"
#include "ctype.h"
#include "stdint.h"
#include "unistd.h"
bool isValidKey(char c1, char &c2){
	if(isdigit(c1) || isalpha(c1)){
		if(isdigit(c1)) c2 = c1 - '0';
		else if(isalpha(c1)) c2 = c1 - 'a' + 10;
		return true;
	}else{
		return false;
	}
}
int CryptCheck(char *argv[], int argc, int type, int name){
	if(argc < 4 || argc > 5 )
		{
			fprintf(stderr, "Error: malformed command'\n");
			return 0;
		}
		if(argv[2][0] != '-' || argv[3][0] != '-')
		{
			fprintf(stderr, "Error: malformed command\n");
			return 0;
		}
		char c;
		FILE *fp =NULL;
		char* fileName;
		unsigned char *key = NULL;
		for(int i = 2; i < 4; i++){
			c = argv[i][1];
			if(c == 't')
			{
				fileName = argv[i]+3;
				if(access (fileName, F_OK) != -1){
					fp = fopen(fileName, "r");
					if(fp == NULL){
						fprintf(stderr, "Error: Can't open %s\n", fileName);
						return 0;
					}
				}else{
					fprintf(stderr, "Error: Can't open input file. File doesn't exist!\n");
					return 0;
				}
				//table check
				if(!tablecheck(fp)){
					return 0;
				}
			}else if(c == 'k'){
				
				if(type == 0){ // DES mode
					key = (unsigned char*)malloc(8 * sizeof(char));
				} else{
					key = (unsigned char *)malloc(24 * sizeof(char));
				}
				//check the key 
				char * srckey = argv[2]+3;
				int len1 = (int)strlen(srckey);
				int len = 16;
				char s1 = 0;
				char s2 = 0;
				if(type == 1){ //DES_EDE === 1
					len = 48;
				}
				if(len1 !=  len){
					fprintf(stderr, "Error: The length of the key is incorrect!\n");
					return 0;
				}
				for(int pp = 0; pp < len; pp += 2){
					if(isValidKey(srckey[pp+1], s1) && isValidKey(srckey[pp], s2)){
						key[pp/2] = (s2 << 4) + s1;
					}else{
						fprintf(stderr, "Malformed key!!! \n");
						return 0;
					}
				}
			}else 
			{
				fprintf(stderr, "Error: malformed command, invalid command option\n");
				return 0;
			}
		}
		
		FILE *fp1 = stdin;
		if(argc == 5)
		{
			fileName = argv[4];
				if(access (fileName, F_OK) != -1){
					fp1 = fopen(fileName, "r");
					if(fp1 == NULL){
					fprintf(stderr, "Error: Can't open %s\n", fileName);
						return 0;
					}
				}else{
					fprintf(stderr, "Error: Can't open input fileFile doesn't exist!\n");
					return 0;
				}
		}
		//long long unsigned k = 0;
		uint64_t key_int = 0;
		if(type == 0){
			for(int i = 0; i < 8; i++){
				long long unsigned tmp4 = key[i];
				(key_int) = (key_int) << 8;
				(key_int) = (key_int) + tmp4;
			}
		}
		if(type == 0 && name == 2){
			crypt(key_int, fp1, stdout, 0); //DES normal encrypt
		}else if(type == 0 && name == 4){
			crypt(key_int, fp1, stdout, 1); //DES normal decrypt
		}else if(type == 1 && name == 2){
			EDEcrypt(key, fp1, 0); //DES EDE encrypt
		}else if(type == 1 && name == 4){
			EDEcrypt(key, fp1, 1); //DES EDE decrypt
		}
		return 1;
}

int main(int argc, char *argv[])
{
	FILE *fp = stdin;
	char * table_file = NULL;
	char c = 0;
	if(argc < 2)
	{
		fprintf(stderr, "Error:malformed command.\n");
		return 0;
	}
	if(argc > 5)
	{
		fprintf(stderr, "Error: malformed command.\n");
		return 0;
	}
	if(strcmp(argv[1],"tablecheck") == 0)   //if the command is "tablecheck"
	{
		if(argc != 3 )
		{
			fprintf(stderr, "Error: malformed command\n");
			return 0;
		}
		if(argv[2][0] != '-')
		{
			fprintf(stderr, "Error:malformed command\n");
			return 0;
		}
		c = argv[2][1];
		if (c == 't'){
				table_file = argv[2] + 2;
		}else {
				fprintf(stderr, "Error: malformed command, invalid command option\n");
				return 0;
		}
		if(table_file[0] != '=')
		{
			fprintf(stderr, "Error: malformed command\n");
			return 0;
		}
		if(access (argv[2]+3, F_OK) != -1){
			fp = fopen(argv[2]+3, "r");
			if(fp == NULL){
				fprintf(stderr, "Error: Can't open %s\n", argv[2]+3);
				return 0;
			}
		}else{
			fprintf(stderr, "Error: Can't open input file. File doesn't exist!\n");
			return 0;
		}
		tablecheck(fp);
		return 1;
	}

	if(strcmp(argv[1],"encrypt") == 0)      //if the command is "encrypt"
	{
		CryptCheck(argv, argc, 0, 2);
		return 1;
	}
	if(strcmp(argv[1],"decrypt") == 0)          //if the command is invkey
	{	
		CryptCheck(argv, argc, 0, 4);
		return 1;
	}
	if(strcmp(argv[1], "encrypt3") == 0){             //if the command is histo
		CryptCheck(argv, argc, 1, 2);
		return 1;
	}
	if(strcmp(argv[1], "decrypt3") == 0)              //if the command is solve
	{
		CryptCheck(argv, argc, 1, 4);
		return 1;
	}
	else
	{
			fprintf(stderr, "Error: malformed command!\n");
			return 0;
	}
	return 1;
}
