#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "unistd.h"
#include "string.h"
#include "stdint.h"
#include <map>
//#include <cstdint>


using namespace std;

extern int IP[64];
extern int E[48];
extern int P[32];
extern int S[8][64];
extern int V[16];
extern int PC1[56];
extern int PC2[48];

void EDEcrypt(unsigned char* key, FILE *ifp, int type);
void crypt(long long unsigned key, FILE *ifp, FILE *ofp, int type);
bool tablecheck(FILE *fp);
