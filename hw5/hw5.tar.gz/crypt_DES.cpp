#include "hw5.h"

void permutation(int Table[], int key_len, int max_len, long long unsigned key, long long unsigned &sub_key){
	 int i = 0;
	//long long unsigned tmp;
	int offset = 0;
	sub_key = 0;
	while(i < key_len){
		offset = max_len - Table[i];
		long long unsigned  set= key >> offset;
		sub_key = (sub_key<<1) + (set & 0x1);
		i++;
	}
	return;
}



void keySchedule(long long unsigned key, long long unsigned * sub_keys){
	//step1: remove the parity bits, remaining 56bits
	long unsigned C0 = 0;
	long unsigned D0 = 0;
 	long long unsigned sub_key = 0;
	permutation(PC1, 56, 64, key, sub_key);

	C0 = sub_key >> 28;
	D0 = sub_key & 0xfffffff;

	fprintf(stderr, "(C0,D0)=%07lx%07lx\n", C0, D0);

	long unsigned Ci = C0;
	long unsigned Di = D0;

	for(int i = 0; i < 16; i++){
		int offset = V[i];
		long unsigned CC = Ci >> (28 - offset);
		long unsigned CC1 = Ci << offset;
		Ci = ( CC | CC1) & 0xfffffff  ;
		long unsigned DD = Di >> (28 - offset);
		long unsigned DD1 = Di << offset;
		Di = (DD | DD1) & 0xfffffff;
		fprintf(stderr, "(C%d,D%d)=%07lx%07lx\n", i+1, i+1, Ci, Di);
		long long unsigned T = Ci;
		T = T << 28;
		T =T | Di;
		permutation(PC2, 48, 56, T, sub_key);
		sub_keys[i] = sub_key;
		fprintf(stderr, "k%d=%012llx\n", i+1, sub_key);
	}

}

//reverse the key array
void reverseKey(long long unsigned  (&sub_keys)[16], int begin, int end){
	long long unsigned tmp = 0;
	if(begin >= end) return;
	tmp = sub_keys[begin];
	sub_keys[begin] = sub_keys[end];
	sub_keys[end] = tmp;
	reverseKey(sub_keys, begin + 1, end - 1);
}

void getMessage(long long unsigned &message, unsigned char buf[]){
	message = 0;
	int i = 0;
	while(i < 8){
		for(int k = 1; k <= 8; k++){
			message = message << 1;
		}
		message = message + buf[i];
		i++;
	}
}

void computeS(long long unsigned c1, long unsigned &y){
	//long unsigned y = 0;
	int i = 0;
	int flag = 0x1;
	int mask = 0x3f;
	while(i < 8){
		int offset = 42 - 6*i;
		int xx = (((c1 >> offset) & mask )>> 5) & flag;
		xx = xx * 2;
		xx = xx + (((c1 >> offset) & mask ) & flag);
		int yy = (((c1 >> offset) & mask ) >> 1) & 0xf;
		yy = xx * 16 + yy;
		y <<= 4;
		y = y + S[i][yy];
		i++;
	}
	

}
void crypt(long long unsigned key, FILE *fp, FILE *ofp, int type){
	long long unsigned sub_keys[16];
	keySchedule(key, sub_keys);
	int flag = 1;
	if(type == 1){ // decrypt
		reverseKey(sub_keys, 0, 15);
	}
	long long unsigned message = 0;
	
	while(!feof(fp)){
		unsigned char buf[8] = {0};
		int len = fread(buf, sizeof(char), 8, fp);
		if(!feof(fp) || len){
				message = 0;
				getMessage(message, buf);
				///printf("%llu\n", message);
				
				//step1: IP permutation
				long long unsigned message_tmp = 0;
				permutation(IP, 64, 64, message,  message_tmp);
				long unsigned Li = 0, Ri = 0;
				Li = message_tmp >> 32;
				Ri = message_tmp & 0xffffffff;
				if(flag == 1){
					fprintf(stderr, "(L0,R0)=%08lx%08lx\n", Li, Ri);
				}
				for(int i = 0; i < 16; i++){
					long unsigned tmp1 = Ri;
					//compute Ri
					long long unsigned c1 = 0;
					int len1 = 48;
					int len2 = 32;
					permutation(E, len1, len2, Ri, c1);
					c1 ^= sub_keys[i]; 
					long unsigned y = 0;
					computeS(c1, y);
					permutation(P, len2, len2, y, c1);
					c1 = Li ^ c1;
					Ri = c1;
					Li = tmp1;
					if(flag == 1){
						fprintf(stderr, "(L%d,R%d)=%08lx%08lx\n", i + 1, i + 1, Li, Ri);
					}

				}			
 				flag = 0;
				//reverse IP
				int IP_inver[64];
				for(int i = 0; i < 64; i++){
					int tmp = i+1;
					IP_inver[IP[i]-1] = tmp;
				}
				long long unsigned ciper = 0;
				ciper = Ri;
				ciper = ciper << 32;
				ciper += Li;
				int lenx = 64;
				long long unsigned ciper_rst = 0;
				permutation(IP_inver, lenx, lenx, ciper, ciper_rst);
				int mask = 0xff;
				for(int i = 0; i < 8; i++){
					char c;
					int m = 8 * i;
					int offset = 56 - m;
					c = (ciper_rst >> offset) & mask;
					fprintf(ofp, "%c", c);
				}
			}

	}

}
void getSubkeys(unsigned char* key, int start, int end, long long unsigned &keyi){
	keyi = 0;
	unsigned char subkey1[8];
	int count = 0;
	for(int i = start; i < end; i++){
		subkey1[count] = key[i];
		count++;
	}
	for(int i = 0; i < 8; i++){
		long long unsigned tmp4 = subkey1[i];
		(keyi) = (keyi) << 8;
		(keyi) = (keyi) + tmp4;
	}
	return;
}
void EDEcrypt(unsigned char* key, FILE *ifp, int type){
	FILE* outfp = NULL;
	outfp = fopen("encrpyt1.tmp", "w");
	uint64_t key1 = 0;
	int mode = type;
	//Encrypt
	if(mode == 0){
		getSubkeys(key, 0, 8, key1);
	}else{
		getSubkeys(key, 16, 24, key1);
	}
	crypt(key1, ifp, outfp, type);
	fclose(outfp);
	//Decrypt
	getSubkeys(key, 8, 16, key1);
	outfp = fopen("encrpyt1.tmp", "r");
	FILE* decryptfp = NULL;
	decryptfp = fopen("decrypt1.tmp", "w+");
	type = (type + 1) % 2;
	crypt(key1, outfp, decryptfp, type);
	type = (type + 1) % 2;
	fclose(decryptfp);
	//Encrypt
	if(mode == 0){
		//keyi = 0;
		unsigned char subkey1[8];
		int count = 0;
		for(int i = 16; i < 24; i++){
			subkey1[count] = key[i];
			count++;
		}
		for(int i = 0; i < 8; i++){
			long long unsigned tmp4 = subkey1[i];
			(key1) = (key1) << 8;
			(key1) = (key1) + tmp4;
		}
	}else{
		getSubkeys(key, 0, 8, key1);
	}
	decryptfp = fopen("decrypt1.tmp", "r");
	crypt(key1, decryptfp, stdout, type);
	remove("decrypt1.tmp");
	remove("encrpyt1.tmp");
}





