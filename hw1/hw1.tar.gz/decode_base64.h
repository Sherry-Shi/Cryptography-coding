//#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>
#include "stdio.h"

void Decode_base64(FILE *fp);

