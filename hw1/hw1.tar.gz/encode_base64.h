
#include <iostream>
#include <fstream>
#include <string>
#include "stdio.h"

void Encode_base64(FILE *fp);




