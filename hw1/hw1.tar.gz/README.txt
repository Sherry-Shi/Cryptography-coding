Hw1

This program does hexdump,base64 encoding and decoding.
This program includes files hw1.cpp encode_base64.cpp encode_base64.h decode_base64.cpp decode_base64.h
usage: run this program in the format: ./hw1 hexdump [file] or ./hw1 enc-base64 [file] or ./hw1 dec-base64 [file]

The command to compile the code to generate hw1: make hw1
to clean all the .o file, the command is: make clean